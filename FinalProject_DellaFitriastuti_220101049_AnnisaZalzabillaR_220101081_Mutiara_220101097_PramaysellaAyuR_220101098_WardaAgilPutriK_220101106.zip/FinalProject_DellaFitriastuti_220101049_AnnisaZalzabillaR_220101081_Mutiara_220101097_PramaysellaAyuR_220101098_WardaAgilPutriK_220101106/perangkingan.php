<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Halaman Perangkingan</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    <div id="app">
        <?php
        require "layout/head.php";
        require "include/conn.php";
        require "layout/sidebar.php";
        require "W.php";
        require "R.php";
        ?>

        <?php
        

        $P = array();
        $m = count($W);
        

        foreach ($R as $i => $r) {
            $P[$i] = 0;
            for ($j = 0; $j < $m; $j++) {
                $P[$i] += $r[$j] * $W[$j];
            }
        }


        $nilaiArray = array();
        foreach ($R as $i => $r) {
            $stmt = $db->prepare("SELECT name FROM saw_alternatives WHERE id_alternative = ?");
            $stmt->bind_param("i", $i);
            $stmt->execute();
            $result = $stmt->get_result();
            $row = $result->fetch_object();
            $stmt->close();

            $nilaiArray[] = array(
                'index' => $i,
                'name' => $row->name,
                'nilai' => round($P[$i], 2)
            );
        }


        usort($nilaiArray, function($a, $b) {
            return $b['nilai'] - $a['nilai'];
        });
        ?>

        <div id="main">
        <header class="mb-3">
        <a href="#" class="burger-btn d-block d-xl-none">
            <i class="bi bi-file-earmark-bar-graph-fill"></i>
        </a>
            </header>
            <div class="page-heading">
                <h3>PERANGKINGAN</h3>
            </div>
            <div class="page-content">
                <section class="row">
                    <div class="col-12">
                        <div class="card">
                            <div class="card-content">
                                <div class="card-body">
                                    <p class="card-text">
                                        Berikut adalah tabel Hasil Perangkingan
                                    </p>
                                </div>
                                <div class="table-responsive">
                                    <table id="ranking-table" class="table table-striped mb-0">
                                        <caption>Perangkingan Alternatif</caption>
                                        <thead>
                                            <tr>
                                                <th class="text-center">Ranking</th>
                                                <th class="text-center">Alternatif</th>
                                                <th class="text-center">Nama</th>
                                                <th class="text-center">Nilai Preferensi</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php
                                            $no = 0;
                                            foreach ($nilaiArray as $data) {
                                                echo "<tr class='center'>
                                                        <td class='text-center'>" . (++$no) . "</td>
                                                        <td class='text-center'>A{$data['index']}</td>
                                                        <td class='text-center'>{$data['name']}</td>
                                                        <td class='text-center nilai'><b>{$data['nilai']}</b></td>
                                                      </tr>";
                                            }
                                            ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </section>
            </div>
            <?php require "layout/footer.php";?> 
        </div>
    </div>
    <?php require "layout/js.php";?>
</body>
</html>