<!DOCTYPE html>
<html lang="en">
  <?php
    require "layout/head.php";
    require "include/conn.php";
  ?>
<body>
  <div id="app">
    <?php require "layout/sidebar.php";?>
    <div id="main">
      <header class="mb-3">
        <a href="#" class="burger-btn d-block d-xl-none">
          <i class="bi bi-justify fs-3"></i>
        </a>
      </header>
      <div class="page-heading">
        <h3>Kriteria & Bobot</h3>
      </div>
      <div class="page-content">
        <section class="row">
          <div class="col-12">
            <div class="card">
              <div class="card-content">
                <div class="card-body">
                  <p class="card-text">Pengambil keputusan memberi bobot preferensi dari setiap kriteria dengan masing-masing jenisnya (Benefit atau Cost) :</p>
                </div>
                <hr>
                <div class="table-responsive">
                  <table class="table table-striped mb-0" style="width: 1100px;margin-left: 30px;margin-right: 30px;">
                  <caption> Tabel Kriteria (C<sub>i</sub>) </caption>
                  <tr>
                    <th class="text-center">No</th>
                    <th class="text-center">Simbol</th>
                    <th class="text-center">Kriteria</th>
                    <th class="text-center">Bobot</th>
                    <th class="text-center">Atribut</th>
                  </tr>
                  <?php
                    $sql = 'SELECT id_criteria,criteria,weight,attribute FROM saw_criterias';
                    $result = $db->query($sql);
                    $i = 1;
                    while ($row = $result->fetch_object()) {
                        echo "<tr>
                            <td class='text-center'>" . ($i++) . "</td>
                            <td class='text-center'>C{$row->id_criteria}</td>
                            <td class='text-center'>{$row->criteria}</td>
                            <td class='text-center'>{$row->weight}</td>
                            <td class='text-center'>{$row->attribute}</td>
                            <td class='text-center'>
                            </td>
                          </tr>\n";
                    }
                    $result->free();
                  ?>
                  </table>
                </div>
              </div>
            </div>
          </div>
        </section>
      </div>
      <?php require "layout/footer.php";?>
    </div>
  </div>
  <?php require "layout/js.php";?>
</body>
</html>