
# Sistem Pendukung Keputusan (SPK) Penilaian Karyawan Terbaik Berbasis Web dengan Metode SAW ( Studi Kasus PT . JiaCorp )

## Deskripsi Proyek
Proyek ini merupakan implementasi Sistem Pendukung Keputusan (SPK) untuk penilaian karyawan menggunakan metode Simple Additive Weighting (SAW). Metode SAW dipilih karena kemampuannya dalam menghitung nilai preferensi berdasarkan bobot yang telah ditentukan untuk setiap kriteria yang dievaluasi.

## Fitur Utama 
    1. Input data karyawan dan kriteria penilaian.
    2. Perhitungan nilai preferensi menggunakan metode SAW.
    3. Tampilan hasil penilaian karyawan berdasarkan nilai preferensi.
    4. Integrasi dengan database untuk menyimpan dan mengelola data karyawan dan penilaian.

## Instalasi Dan Penggunaan
    1. Persyaratan Sistem
    - Pastikan telah terinstall web server PHP dan database MySQL.
    2. Menyiapkan Proyek
    - Clone repositori ini ke dalam direktori web server (htdocs untuk XAMPP).
    3. Konfigurasi database
    - Buatlah database lalu import database yang terdapat pada file ini.
    4. Konfigurasi Koneksi database
    - Edit file include/conn.php sesuaikan dengan pengaturan database lokal Anda.
    5. Menjalankan Web
    - Buka browser dan akses aplikasi melalui URL lokal (misalnya http://localhost/namaprojek).
    - Login sebagai administrator atau pengguna yang memiliki hak akses untuk mengelola data karyawan dan penilaian.

## Teknologi Yang Digunakan 
    - PHP: Bahasa pemrograman utama untuk logika backend.
    - MySQL: Basis data untuk menyimpan data karyawan dan hasil penilaian.
    - HTML/CSS/JavaScript: Untuk antarmuka pengguna (frontend) dan pengaturan tampilan.
    - Bootstrap: Framework front-end untuk memperindah tampilan antarmuka.

## Kontribusi
Kontribusi terbuka untuk perbaikan bug, pengembangan fitur baru, atau peningkatan dokumentasi.

## Lisensi
Tidak ada lisensi khusus yang disertakan untuk proyek ini.
