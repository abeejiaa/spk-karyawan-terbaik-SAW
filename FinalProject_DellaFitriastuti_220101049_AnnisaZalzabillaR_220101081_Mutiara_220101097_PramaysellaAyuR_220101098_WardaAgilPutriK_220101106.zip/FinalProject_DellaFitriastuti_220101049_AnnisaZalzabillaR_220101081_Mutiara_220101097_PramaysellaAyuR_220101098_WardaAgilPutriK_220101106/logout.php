<?php
    session_start();
    if (isset($_POST['logout'])) {
        session_destroy();
        header("Location: login.php");
        exit();
    }
?>
<!DOCTYPE html>
<html>
<head>
    <title>Logout</title>
    <script type="text/javascript">
        function confirmLogout() {
            var confirmation = confirm("Apakah Anda ingin logout?");
            if (confirmation) {
                document.getElementById('logoutForm').submit();
            } else {
                window.location.href = "index.php"; // Mengarahkan ke halaman utama atau halaman lain
            }
        }
    </script>
</head>
<body onload="confirmLogout()">
    <form id="logoutForm" method="post" action="">
        <input type="hidden" name="logout" value="true">
    </form>
</body>
</html>
