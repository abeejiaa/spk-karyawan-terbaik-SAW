<footer>
    <div class="footer clearfix mb-0 text-muted text-center">
        <div>
            <p class="text-center">&copy;2024 JIA_CORP - SPK Metode SAW</p>
        </div>
    </div>
</footer>
